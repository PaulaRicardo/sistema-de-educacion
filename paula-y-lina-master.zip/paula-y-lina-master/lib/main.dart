import 'package:flutter/material.dart';
import 'clases.dart';

void main() async
{
  Data.connected = await Data.getData();
  runApp(MaterialApp(home: Carga(),));

}


class Carga extends StatefulWidget {
  @override
  _CargaState createState() => _CargaState();
}

class _CargaState extends State<Carga> {
  @override
  Widget build(BuildContext context) {

    if (Data.connected)
      return Login();

    else
      return NoNet();

  }
}

class NoNet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Ups... Parece que no tienes conexión a internet..."),);

  }
}




class Login extends StatefulWidget {
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {


  TextEditingController ctrl1 = new TextEditingController();
  TextEditingController ctrl2 = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(


      appBar: AppBar(
        title: Text("Login"),
        centerTitle: true,

      ),




      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[

          Container(
            margin: EdgeInsets.only(left: 50,right: 50,bottom: 20),
            child: TextField(

              controller: ctrl1,
              decoration: InputDecoration(
                hintText: "Usuario"
              ),

            ),
          ),



          Container(
            margin: EdgeInsets.only(left: 50,right: 50,bottom: 20),
            child: TextField(

              controller: ctrl2,
              obscureText: true,
              decoration: InputDecoration(
                  hintText: "Contraseña",
              ),

            ),
          ),


          RaisedButton(
            onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => Menu()));
            },
            child: Text("Iniciar Sesion"),

          )


        ],
      ),


    );
  }
}



class Menu extends StatefulWidget {
  @override
  _MenuState createState() => _MenuState();
}

class _MenuState extends State<Menu> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text("Menú"),
      ),






      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[

            Container(
              width:150,
              margin: EdgeInsets.only(bottom: 25),
              child: RaisedButton(

                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Cursos()));
                  },
                  child: Text("Ver cursos"),

              ),
            ),

            Container(
              width: 150,
              child: RaisedButton(

                onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>Estudiantes()));
                },
                child: Text("Ver Estudiantes"),

              ),
            ),

          ],
        ),
      ),




    );
  }
}



class Cursos extends StatefulWidget {
  @override
  _CursosState createState() => _CursosState();
}

class _CursosState extends State<Cursos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(


      appBar: AppBar(
        title: Text("Cursos disponibles"),
      ),

      body: Center(
        child: Container(
          margin: EdgeInsets.fromLTRB(30, 20, 30, 20),
          child: ListView.builder(
            itemCount: Data.cursos.length,
            itemBuilder: (context,index)
            {

              return Card(
                child: ListTile(
                  leading: Text("${Data.cursos[index].id}",style: TextStyle(fontSize: 18),),
                  title: Text("${Data.cursos[index].nombre}"),
                  trailing: Text("${Data.cursos[index].cupos} Cupos"),
                ),
              );


            },
          ),
        ),
      ),


    );
  }
}


class Estudiantes extends StatefulWidget {
  @override
  _EstudiantesState createState() => _EstudiantesState();
}

class _EstudiantesState extends State<Estudiantes> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

        appBar: AppBar(
          title: Text("Estudiantes"),
        ),



        body: Center(
          child: Container(
            margin: EdgeInsets.fromLTRB(30, 20, 30, 20),
            child: ListView.builder(
              itemCount: Data.estudiantes.length,
              itemBuilder: (context,index)
              {

                return Card(
                  child: ListTile(
                    leading: Text("${Data.estudiantes[index].id}",style: TextStyle(fontSize: 18),),
                    title: Text("${Data.estudiantes[index].nombre} ${Data.estudiantes[index].apellido}"),
                    onTap: (){
                      Navigator.push(context, MaterialPageRoute(builder: (context) => MateriasPersona(Data.estudiantes[index])));
                    },
                  ),
                );


              },
            ),
          ),
        )
    );
  }
}


class MateriasPersona extends StatefulWidget {
  @override
  _MateriasPersonaState createState() => _MateriasPersonaState(this.est);

  Estudiante est;
  MateriasPersona(this.est);

}

class _MateriasPersonaState extends State<MateriasPersona> {

  Estudiante est;
  _MateriasPersonaState(this.est);

  @override
  Widget build(BuildContext context) {
    return Scaffold(


      appBar: AppBar(
        title: Text("${est.nombre} ${est.apellido}"),
      ),


      body: FutureBuilder(
        future: Data.MateriasMatriculadas(est),
        builder: (context,snapshot)
        {

          if (snapshot.connectionState == ConnectionState.waiting)
            {
              return Center(child: CircularProgressIndicator());
            }

          else
            {

              if (Data.cursosBuscado.length > 0)
                return Center(
                child: Container(
                  margin: EdgeInsets.fromLTRB(30, 20, 30, 20),
                  child: ListView.builder(
                    itemCount: Data.cursosBuscado.length,
                    itemBuilder: (context,index)
                    {

                      if(Data.cursosBuscado.length == 0)
                        {
                          return
                              Center(child: Text("No tiene ningún curso matriculado"),);
                        }
                      else
                      return Card(
                        child: ListTile(
                          leading: Text("${Data.cursosBuscado[index].id}",style: TextStyle(fontSize: 18),),
                          title: Text("${Data.cursosBuscado[index].nombre}"),
                          trailing: Text("${Data.cursosBuscado[index].cupos} Cupos"),
                        ),
                      );


                    },
                  ),
                ),
              );




              else
                return Center(
                  child: Text("No tiene ningún curso matriculado"),
                );
            }


        },
      ),




    );
  }
}




