import 'package:mysql1/mysql1.dart';
import 'dart:async';

class Curso
{
  int id,cupos;
  String nombre;

  Curso([this.id,this.nombre,this.cupos]);

}

class Estudiante
{

  int id;
  String nombre,apellido;

  Estudiante([this.id,this.nombre,this.apellido]);

}

class Matricula
{

  int id,id_curso,id_estudiante;

  Matricula([this.id,this.id_curso,this.id_estudiante]);

}


class Data
{
  static var settings = new ConnectionSettings();
  static var conn;

  static bool connected = false;

  static List<Curso> cursos = new List<Curso>();
  static List<Curso> cursosBuscado = new List<Curso>();
  static List<Estudiante> estudiantes = new List<Estudiante>();
  static List<Matricula> matriculas = new List<Matricula>();



  static Future<bool> getData() async
  {

    if (await loadSettings() && await loadEstudiantes() && await loadCursos() && await loadMatriculas() )
      return true;

    return false;



  }

  static Future<bool> loadSettings() async
  {

    try
    {
      settings = new ConnectionSettings(
          host: 'remotemysql.com',
          port: 3306,
          user: 'I6ZXyVeWvz',
          password: 'HESDUyjYVb',
          db: 'I6ZXyVeWvz'
      );

      conn = await MySqlConnection.connect(settings);
      return true;
    }

    catch(e)
  {
    return false;
  }


  }


  static Future<bool> loadEstudiantes() async
  {



    try
    {
      var results = await conn.query('SELECT * FROM estudiantes');
      for (var row in results)
      {
        print('Name: ${row[0]}, email: ${row[1]}');
      };

      for (var row in results)
      {
        estudiantes.add(Estudiante(row[0],row[1],row[2]));
      };


      print("Se obtuvieron ${Data.estudiantes.length} estudiantes.");
      return true;


    }

    catch(e)
    {
    return false;
    }


  }

  static Future<bool> loadCursos() async
  {

    try
    {

      var results = await conn.query('SELECT * FROM clases');

      for (var row in results)
      {
        print('Name: ${row[0]}, email: ${row[1]}');
      };

      for (var row in results)
      {
        cursos.add(Curso(row[0],row[1],row[2]));
      };

      print("Se obtuvieron ${Data.cursos.length} cursos");

      return true;

    }

    catch(e)
    {
    return false;
    }






  }

  static Future<bool> loadMatriculas() async
  {
    try {
      var results = await conn.query('SELECT * FROM matriculas');

      for (var row in results) {
        matriculas.add(Matricula(row[0], row[1], row[2]));
      };

      print("Se obtuvieron ${Data.matriculas.length} matriculas");
      return true;
    }

    catch (e) {
      return false;
    }
  }

  static Curso cursoPorID(int id)
  {

    var curso = new Curso();

    for (var x in cursos)
      {

        if (x.id == id)
          {
            curso = x;
          }

      }

    return curso;


  }


  static Future<List<Curso>> MateriasMatriculadas(Estudiante estudiante) async
  {

    var cursoss = new List<Curso>();
    var matriculass = new List<Matricula>();

    try{
      var results = await conn.query("SELECT * FROM matriculas where id_estudiante = ${estudiante.id}");

      for (var row in results)
      {
        matriculass.add(Matricula(row[0],row[1],row[2]));
      };

      for (var x=0 ; x < matriculass.length ; x++)
        {

          for (var j in cursos)
            {
              if (matriculass[x].id_curso == j.id)
                {
                  cursoss.add(j);
                }
            }

        }


      cursosBuscado = cursoss;
      return cursoss;

    }

    catch(e)
    {

    }

  }


}